package edu.cnu.mdi.splot.fit;

import java.util.Arrays;
import java.util.stream.IntStream;

import org.apache.commons.math3.linear.RealMatrix;

import edu.cnu.mdi.util.SmartDoubleFormatter;
import edu.cnu.mdi.util.UnicodeUtils;

/**
 * Generic result for a (weighted) least-squares fit.
 * <p>
 * This class is intentionally model-agnostic: it stores parameter values and
 * common diagnostics that apply across nonlinear and linear least-squares fits
 * (Gaussian, erf/erfc, exponential, polynomial, etc.).
 */
public final class FitResult {

	// helpers from unicode
	public static final String CHI = UnicodeUtils.SMALL_CHI;
	public static final String CHISQ = CHI + UnicodeUtils.SUPER2;
	public static final String PLUSMINUS = UnicodeUtils.PLUSMINUS;

	/** Best-fit parameters. Interpretation depends on the model. */
	public final double[] params;

	/** Gets descriptive strings from fitter */
	public IFitStringGetter stringGetter;

	/** Optional covariance matrix of parameters (p x p), or null if unavailable. */
	public final RealMatrix covariance;

	/**
	 * Least-squares cost: sqrt(sum r_i^2) where r_i are residuals. If weights are
	 * used, r_i are in the weighted residual space.
	 */
	public final double cost;

	/** Chi-square: sum r_i^2 = cost^2 (weighted if weights used). */
	public final double chiSquare;

	/** Degrees of freedom: max(1, nPoints - nParameters). */
	public final int dof;

	/** Reduced chi-square: chiSquare / dof. */
	public final double chiSquareReduced;

	/** RMS of residuals (same residual space as optimizer). */
	public final double rms;

	/** Iterations used by an iterative optimizer; may be 0 for closed-form fits. */
	public final int iterations;

	/**
	 * Evaluations used by an iterative optimizer; may be 0 for closed-form fits.
	 */
	public final int evaluations;

	/** "Use as a function" evaluator for the fit. */
	public Evaluator evaluator;

	/**
	 * Create a fit result.
	 *
	 * @param stringGetter     access to descriptive strings about fitter
	 * @param params           best-fit parameters
	 * @param covariance       optional covariance matrix (may be null)
	 * @param cost             least-squares cost
	 * @param chiSquare        chi-square
	 * @param dof              degrees of freedom
	 * @param chiSquareReduced reduced chi-square
	 * @param rms              RMS of residuals
	 * @param iterations       iterations used (0 if not applicable)
	 * @param evaluations      evaluations used (0 if not applicable)
	 */
	protected FitResult(IFitStringGetter stringGetter, double[] params, RealMatrix covariance, double cost,
			double chiSquare, int dof, double chiSquareReduced, double rms, int iterations, int evaluations) {

		this.stringGetter = stringGetter;
		this.params = params.clone();
		this.covariance = covariance;
		this.cost = cost;
		this.chiSquare = chiSquare;
		this.dof = dof;
		this.chiSquareReduced = chiSquareReduced;
		this.rms = rms;
		this.iterations = iterations;
		this.evaluations = evaluations;
	}

	/**
	 * Set the evaluator.
	 *
	 * @param evaluator
	 */
	public void setEvaluator(Evaluator evaluator) {
		this.evaluator = evaluator;
	}

	/** @return number of parameters. */
	public int nParams() {
		return params.length;
	}

	/** Convenience access to parameter i. */
	public double param(int i) {
		return params[i];
	}

	/** @return true if covariance is present. */
	public boolean hasCovariance() {
		return covariance != null;
	}

	/**
	 * Standard errors for parameters computed from covariance: sqrt(cov[i,i]).
	 * Returns NaN for entries where covariance is missing or diagonal is
	 * non-positive.
	 */
	public double[] paramStdErrors() {
		double[] se = new double[params.length];
		if (covariance == null) {
			Arrays.fill(se, Double.NaN);
			return se;
		}

		int p = Math.min(params.length, Math.min(covariance.getRowDimension(), covariance.getColumnDimension()));

		Arrays.fill(se, Double.NaN);
		for (int i = 0; i < p; i++) {
			double v = covariance.getEntry(i, i);
			se[i] = (v > 0.0 && Double.isFinite(v)) ? Math.sqrt(v) : Double.NaN;
		}
		return se;
	}

	/** Standard error for parameter i (NaN if unavailable). */
	public double paramStdError(int i) {
		if ((covariance == null) || i < 0 || i >= covariance.getRowDimension()
				|| i >= covariance.getColumnDimension()) {
			return Double.NaN;
		}
		double v = covariance.getEntry(i, i);
		return (v > 0.0 && Double.isFinite(v)) ? Math.sqrt(v) : Double.NaN;
	}

	/**
	 * HTML summary of the fit result.
	 *
	 * @return HTML string
	 */
	public String htmlSummary() {
		String BR = "<br>";
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body>");

		sb.append("<b>Fit Result:</b>" + BR);
		sb.append(" Model: " + stringGetter.modelName() + BR);
		sb.append(" Form: " + stringGetter.functionForm() + BR);
		sb.append("<b> Parameters:</b>" + BR);

		IntStream.range(0, params.length).forEach(i -> sb.append(String.format(" %s = %.3g%s%.3g%n",
				stringGetter.parameterName(i), params[i], PLUSMINUS, paramStdError(i)) + BR));
		sb.append(String.format(" %s: %.3g%n", CHISQ, chiSquare) + BR);
		sb.append(String.format(" %s/DoF: " + doubleFormat(chiSquareReduced, 3) + "%n", CHISQ) + BR);
		sb.append(" DoF: " + dof + BR);
		sb.append(" Iterations: " + iterations + BR);
		sb.append(" Evaluations: " + evaluations + BR);
		sb.append("</body></html>");
		return sb.toString();
	}

	/**
	 * Single-line text summary of the fit result.
	 *
	 * @return single-line string
	 */
	public String singleLineSummary() {
		StringBuilder sb = new StringBuilder();
		sb.append(" " + stringGetter.functionForm());
		sb.append(" ");
		IntStream.range(0, params.length).forEach(i -> sb.append(String.format(" %s=%.2g%s%.2g",
				stringGetter.parameterName(i), params[i], PLUSMINUS, paramStdError(i))));
		sb.append(String.format(" %s/DoF: " + doubleFormat(chiSquareReduced, 2), CHISQ));
		return sb.toString();
	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append("FitResult:\n");
		sb.append(" Model: " + stringGetter.modelName() + "\n");
		sb.append(" Form: " + stringGetter.functionForm() + "\n");
		sb.append(" Parameters:\n");

		IntStream.range(0, params.length)
				.forEach(i -> sb.append(String.format(" %s = %.3g%n", stringGetter.parameterName(i), params[i])));
		sb.append(String.format(" %s: %.3g\n", CHISQ, chiSquare));
		sb.append(String.format(" %s/DoF: " + doubleFormat(chiSquareReduced, 3) + "\n", CHISQ));
		sb.append(" Degrees of Freedom: " + dof + "\n");
		sb.append(String.format(" RMS: %.3g\n", rms));
		sb.append(" Iterations: " + iterations + "\n");
		sb.append(" Evaluations: " + evaluations + "\n");
		return sb.toString();
	}

	// Helper to format doubles
	private String doubleFormat(double value, int sigFig) {
		return SmartDoubleFormatter.doubleFormat(value, sigFig);
	}
}
