package edu.cnu.mdi.splot.plot;

import java.awt.Graphics2D;
import java.awt.Point;

import edu.cnu.mdi.graphics.GraphicsUtils;
import edu.cnu.mdi.graphics.style.Styled;

/**
 * Just a straight line to be drawn on the plot, e.g. a y = 0 line
 *
 * @author heddle
 *
 */
public abstract class PlotLine {

	// default style
	protected static Styled _defaultStyle = new Styled();

	// the plot canvas
	protected PlotCanvas _canvas;

	// init style to default
	protected Styled _style = _defaultStyle;

	// work points
	protected Point p0 = new Point();
	protected Point p1 = new Point();
	protected Point.Double wp = new Point.Double();

	/**
	 * Create a PlotLine
	 *
	 * @param canvas the owner canvas
	 */
	public PlotLine(PlotCanvas canvas) {
		_canvas = canvas;
	}

	/**
	 * Set the line drawing style
	 *
	 * @param style the new style
	 */
	public void setStyle(Styled style) {
		_style = style;
	}

	/**
	 * Get the line style
	 *
	 * @return the line style
	 */
	public Styled getStyle() {
		return _style;
	}

	/**
	 * Draw the line on the given graphics context
	 *
	 * @param g2 the graphics context to draw on
	 */
	public void draw(Graphics2D g2) {
		wp.setLocation(getX0(), getY0());

		boolean goodPoint;
		goodPoint = _canvas.dataToScreen(p0, wp);
		if (!goodPoint) {
			return;
		}
		wp.setLocation(getX1(), getY1());

		goodPoint =_canvas.dataToScreen(p1, wp);
		if (!goodPoint) {
			return;
		}

		GraphicsUtils.drawStyleLine(g2, _style.getAuxLineColor(), _style.getAuxLineWidth(), _style.getAuxLineStyle(),
				p0.x, p0.y, p1.x, p1.y);
	}

	/**
	 * Get the starting x coordinate
	 *
	 * @return the starting x coordinate
	 */
	public abstract double getX0();

	/**
	 * Get the ending x coordinate
	 *
	 * @return the ending x coordinate
	 */
	public abstract double getX1();

	/**
	 * Get the starting y coordinate
	 *
	 * @return the starting y coordinate
	 */
	public abstract double getY0();

	/**
	 * Get the ending y coordinate
	 *
	 * @return the ending y coordinate
	 */
	public abstract double getY1();

	@Override
	public String toString() {
		return "PlotLine: (" + getX0() + ", " + getY0() + ") to (" + getX1() + ", " + getY1() + ")";
	}

}
