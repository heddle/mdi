package edu.cnu.mdi.splot.example;

import java.awt.Color;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import edu.cnu.mdi.graphics.style.IStyled;
import edu.cnu.mdi.graphics.style.SymbolType;
import edu.cnu.mdi.splot.fit.CurveDrawingMethod;
import edu.cnu.mdi.splot.fit.Evaluator;
import edu.cnu.mdi.splot.pdata.PlotData;
import edu.cnu.mdi.splot.pdata.PlotDataException;
import edu.cnu.mdi.splot.pdata.StripChartCurve;
import edu.cnu.mdi.splot.plot.LimitsMethod;
import edu.cnu.mdi.splot.plot.PlotChangeType;
import edu.cnu.mdi.splot.plot.PlotParameters;

@SuppressWarnings("serial")
public class StripChart extends AExample implements Evaluator {

	private Random random = new Random();

	public StripChart(boolean headless) {
		super(headless);
		PlotData ds = canvas.getPlotData();
		StripChartCurve sc = (StripChartCurve) ds.getFirstCurve();
		sc.setTimeUnit(TimeUnit.SECONDS);
		PlotParameters params = canvas.getParameters();
		params.setXLabel("Time (" + sc.getTimeUnitShortLabel() + ")");
		sc.start();

	}

	@Override
	protected PlotData createPlotData() throws PlotDataException {
		int capacity = 25;
		int updateTimeMs = 1000;
		StripChartCurve sd = new StripChartCurve("Memory", capacity, this, updateTimeMs);
		return new PlotData(sd);
	}

	@Override
	public void plotChanged(PlotChangeType type) {
		switch (type) {
		case SHUTDOWN:
			PlotData ds = canvas.getPlotData();
			StripChartCurve sc = (StripChartCurve) ds.getFirstCurve();
			sc.stop();
			break;

		case STOODUP:
			// nothing to do
			break;
		}
	}

	@Override
	protected String getXAxisLabel() {
		return "Time (ms)";
	}

	@Override
	protected String getYAxisLabel() {
		return "Heap Memory (MB)";
	}

	@Override
	protected String getPlotTitle() {
		return "Sample Strip Chart";
	}

	@Override
	public void fillData() {
	}

	@Override
	public void setParameters() {
		PlotData ds = canvas.getPlotData();
		StripChartCurve sc = (StripChartCurve) ds.getFirstCurve();
		sc.setCurveDrawingMethod(CurveDrawingMethod.STAIRS);
		IStyled style = sc.getStyle();
		style.setLineColor(Color.red);
		style.setFillColor(new Color(128, 0, 0, 48));
		style.setSymbolType(SymbolType.NOSYMBOL);
		PlotParameters params = canvas.getParameters();
		params.setMinExponentY(6);
		params.setNumDecimalY(2);
		params.setXLimitsMethod(LimitsMethod.USEDATALIMITS);
		params.includeYZero(true);
	}

	@Override
	public double value(double x) {
		// memory in mb

		double megaBytes = 100 * (random.nextDouble() - 0.5) + (Runtime.getRuntime().totalMemory()) / 1048576.;
		return megaBytes;
	}

	public static void main(String arg[]) {

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				StripChart example = new StripChart(false);
				example.setVisible(true);
			}
		});

	}

}
