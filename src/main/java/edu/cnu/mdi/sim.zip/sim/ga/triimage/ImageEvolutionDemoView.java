package edu.cnu.mdi.sim.ga.triimage;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.prefs.Preferences;

import javax.imageio.ImageIO;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.Box;
import javax.swing.JLabel;

import edu.cnu.mdi.sim.SimulationContext;
import edu.cnu.mdi.sim.SimulationEngine;
import edu.cnu.mdi.sim.SimulationEngineConfig;
import edu.cnu.mdi.sim.SimulationState;
import edu.cnu.mdi.dialog.FileDialogs;
import edu.cnu.mdi.dialog.FileType;
import edu.cnu.mdi.sim.ga.GAConfig;
import edu.cnu.mdi.sim.ga.GAFeedback;
import edu.cnu.mdi.sim.ga.GAOperators;
import edu.cnu.mdi.sim.ga.GAState;
import edu.cnu.mdi.sim.ga.GeneticAlgorithmSimulation;
import edu.cnu.mdi.sim.ui.SimulationView;
import edu.cnu.mdi.io.RecentFiles;
import edu.cnu.mdi.io.RecentFilesMenu;
import edu.cnu.mdi.transfer.ImageFilters;
import edu.cnu.mdi.util.Environment;
import edu.cnu.mdi.view.AbstractViewInfo;
import edu.cnu.mdi.view.BaseView;

/**
 * MDI {@link SimulationView} that evolves a population of semi-transparent
 * triangles to approximate a target image using the MDI genetic algorithm
 * framework.
 *
 * <h2>Layout</h2>
 * <p>
 * The view's world container is replaced by a custom
 * {@link ImageEvolutionPanel} installed as the CENTER component. It renders
 * three regions side-by-side:
 * </p>
 * <ul>
 * <li><b>Left</b> — best individual found so far, at full display
 * resolution.</li>
 * <li><b>Center</b> — thumbnail grid of the entire current population.</li>
 * <li><b>Right</b> — the fixed target image.</li>
 * </ul>
 * <p>
 * Fitness and diversity diagnostic plots are installed on the right side of a
 * split pane via the {@link SimulationView} diagnostics mechanism.
 * </p>
 *
 * <h2>Threading</h2>
 * <p>
 * The GA runs on the simulation thread. On each refresh callback (EDT), the
 * view asks the simulation for its best individual, renders it at display
 * resolution, renders all population thumbnails, then hands both to
 * {@link ImageEvolutionPanel} and calls {@code repaint()}.
 * </p>
 *
 * <h2>Reset</h2>
 * <p>
 * The view implements {@link IImageEvolutionResettable} so the control panel
 * can request a fresh run with different parameters without knowing the view's
 * concrete type. Reset is delegated to
 * {@link SimulationView#requestEngineReset}.
 * </p>
 */
@SuppressWarnings("serial")
public class ImageEvolutionDemoView extends SimulationView implements IImageEvolutionResettable {

	// -------------------------------------------------------------------------
	// Defaults
	// -------------------------------------------------------------------------

	/** Default number of triangles per chromosome. */
	public static final int DEFAULT_NUM_TRIANGLES = 150;

	/** Default population size. */
	public static final int DEFAULT_POPULATION_SIZE = 200;

	/**
	 * Pixel size used when rendering population thumbnails. Small enough to be
	 * fast; large enough to see shape.
	 */
	private static final int THUMB_SIZE = 24;

	/**
	 * Size used when rendering the best individual for display in the left panel.
	 * Larger than fitness resolution but not full-screen, to stay fast.
	 */
	private static final int DISPLAY_SIZE = 200;
	private static final FileType IMAGE_FILE_TYPE = FileType.of(
			"Images", ImageIO.getReaderFileSuffixes());

	// -------------------------------------------------------------------------
	// Fields
	// -------------------------------------------------------------------------

	/** The target image loaded at construction. Never null after construction. */
	private BufferedImage targetImage;

	/** The custom drawing panel (CENTER component). */
	private final ImageEvolutionPanel evolutionPanel;

	/** Typed reference to the running simulation. Updated on reset. */
	private GeneticAlgorithmSimulation<PolygonChromosome> sim;
	
	/** Typed reference to the diagnostics panel for pushing GA state updates. */
	private GADiagnosticPlotPanel diagnosticPlots;
	private int requestedTriangles = DEFAULT_NUM_TRIANGLES;
	private int requestedPopulation = DEFAULT_POPULATION_SIZE;
	private ImageFitnessMode requestedFitnessMode = ImageFitnessMode.LINE_AWARE;
	private RecentFiles recentImages;
	private RecentFilesMenu recentImagesHelper;
	private JMenu recentImagesMenu;
	private JMenuItem openImageItem;
	// -------------------------------------------------------------------------
	// Constructor
	// -------------------------------------------------------------------------

	/**
	 * Create the image evolution demo view.
	 *
	 * @param keyVals standard {@link edu.cnu.mdi.view.BaseView} key-value args
	 */
	public ImageEvolutionDemoView(Object... keyVals) {
		super(createSimulation(loadDefaultTarget(), DEFAULT_NUM_TRIANGLES, DEFAULT_POPULATION_SIZE),
			      new SimulationEngineConfig(33, 500, 0, false),
			      true,
			      (SimulationView.ControlPanelFactory) ImageEvolutionControlPanel::new,
			      true,                              // was false
			      GADiagnosticPlotPanel::new,        // for plot
			      0.70,                              // main panel gets 70% of width
			      keyVals);
		
		// Retrieve typed references after super() completes.
		this.diagnosticPlots = (GADiagnosticPlotPanel) getDiagnosticsComponent();

		this.sim = castSim(getSimulationEngine());

		// Load target image (same call used in createSimulation; cheap second load).
		this.targetImage = loadDefaultTarget();

		// Install our custom drawing panel as CENTER.
		// BaseView installs an IContainer in CENTER; we replace it with our own
		// panel so we have full control over the three-region layout.
		evolutionPanel = new ImageEvolutionPanel(targetImage);
		installCenterPanel(evolutionPanel);
		enableFileDrop(ImageFilters.isActualImage);
		// The custom panel fills the left side of the diagnostics split pane. Give
		// it the same framework handler so drops are accepted over the images, not
		// just over split-pane chrome.
		if (diagnosticsSplitPane != null) {
			evolutionPanel.setTransferHandler(diagnosticsSplitPane.getTransferHandler());
		}
		installImageMenu();
		installDropHint();
		updateImageActions(getSimulationState());

		pack();
		startSimulation();
	}

	// -------------------------------------------------------------------------
	// SimulationView overrides
	// -------------------------------------------------------------------------

	/**
	 * {@inheritDoc}
	 * <p>
	 * On each refresh:
	 * </p>
	 * <ol>
	 * <li>Ask the simulation for a copy of the best individual.</li>
	 * <li>Render it at {@link #DISPLAY_SIZE}×{@link #DISPLAY_SIZE} for the left
	 * panel.</li>
	 * <li>Render all current population individuals as
	 * {@link #THUMB_SIZE}×{@link #THUMB_SIZE} thumbnails for the grid.</li>
	 * <li>Push both to {@link ImageEvolutionPanel} and repaint.</li>
	 * </ol>
	 * <p>
	 * All rendering here uses {@link PolygonChromosome#render(int, int)}, which
	 * allocates a new image — this is intentional for display paths. Fitness
	 * evaluation uses the allocation-free {@link PolygonChromosome#renderInto} path
	 * via thread-local buffers.
	 * </p>
	 */
	@Override
	protected void onSimulationRefresh(SimulationContext ctx) {
		// Note: do NOT call super — we are managing our own panel, not an IContainer.

		GeneticAlgorithmSimulation<PolygonChromosome> s = sim;
		if (s == null)
			return;

		long gen = s.getGeneration();

		// Best individual — update every refresh
		PolygonChromosome best = s.getBestIndividualCopy();
		BufferedImage bestImg = (best != null) ? best.render(DISPLAY_SIZE, DISPLAY_SIZE) : null;
		
		GAState state = s.getState();
		
		
		// Update the left panel with the new best image and generation number. The panel
		// will also display the MSE as a quality metric, but it es expecting bestFitness
		// which is -mse.
		evolutionPanel.updateBest(bestImg, gen, state.bestFitness());

		// The engine already throttles refresh delivery. Update the population on
		// every delivered callback rather than testing the observed generation for
		// an exact multiple: the GA can advance between requestRefresh() and this EDT
		// callback, so an equality/modulo test can miss every intended update.
		evolutionPanel.updatePopulation(buildThumbnails(s));
		
		// Update diagnostic plots with the new GA state. This will add a new point to the MSE vs. generation 
		// plot and trigger a repaint. We do this every refresh so the plot updates smoothly, but it could 
		// be throttled if performance is an issue.
		if (diagnosticPlots != null) {
		    diagnosticPlots.update(state);
		}
	}

	@Override
	protected void onSimulationStateChange(SimulationContext ctx,
			SimulationState from, SimulationState to, String reason) {
		updateImageActions(to);
	}

	@Override
	public void filesDropped(List<File> files) {
		if (files != null && !files.isEmpty()) {
			openImageFile(files.get(0));
		}
	}
		
	@Override
	public AbstractViewInfo getViewInfo() {
		return new ImageEvolutionViewInfo();
	}

	// -------------------------------------------------------------------------
	// IImageEvolutionResettable
	// -------------------------------------------------------------------------

	/**
	 * {@inheritDoc}
	 * <p>
	 * Stops the current engine, builds a new simulation with the supplied
	 * parameters, swaps the engine, and restarts against the current target image.
	 * </p>
	 */
	@Override
	public void requestReset(int numTriangles, int populationSize,
			ImageFitnessMode fitnessMode) {
		requestedTriangles = numTriangles;
		requestedPopulation = populationSize;
		requestedFitnessMode = java.util.Objects.requireNonNull(fitnessMode, "fitnessMode");
		resetSimulation(targetImage, numTriangles, populationSize, fitnessMode);
	}

	private void resetSimulation(BufferedImage target, int numTriangles,
			int populationSize, ImageFitnessMode fitnessMode) {
	    requestEngineReset(
	        () -> createSimulation(target, numTriangles, populationSize, fitnessMode),

	        (SimulationEngine newEngine) -> {
	            this.sim = castSim(newEngine);
	            this.sim.setFeedback(GAFeedback.forEngine(newEngine));
	            // Clear plots here — after the swap, on the EDT,
	            // when the old engine is fully stopped
	            if (diagnosticPlots != null) {
	                diagnosticPlots.clearAllPlots();
	            }
	        },

	        true,
	        true
	    );
	}

	private void installDropHint() {
		if (getToolBar() == null) {
			return;
		}
		getToolBar().add(Box.createHorizontalGlue());
		JLabel hint = new JLabel("Drop an image here while paused or stopped  ");
		hint.setToolTipText("You can also use Image > Open Image…");
		getToolBar().add(hint);
	}

	private void installImageMenu() {
		JMenuBar menuBar = getJMenuBar();
		if (menuBar == null) {
			menuBar = new JMenuBar();
			setJMenuBar(menuBar);
		}
		Preferences preferences = Preferences.userNodeForPackage(getClass())
				.node("imageEvolution");
		recentImages = new RecentFiles(preferences, 10, "recentTargetImage");
		recentImagesHelper = new RecentFilesMenu(recentImages,
				this::openImageFile, "images");

		JMenu imageMenu = new JMenu("Image");
		openImageItem = new JMenuItem("Open Image…");
		openImageItem.addActionListener(event -> chooseImage());
		imageMenu.add(openImageItem);
		recentImagesMenu = new JMenu("Recent Images");
		recentImagesHelper.rebuild(recentImagesMenu);
		imageMenu.add(recentImagesMenu);
		BaseView.applyFocusFix(imageMenu, this);
		menuBar.add(imageMenu);
	}

	private void chooseImage() {
		FileDialogs.openFile(this, "image-evolution-target", "Open Target Image",
				IMAGE_FILE_TYPE).ifPresent(path -> openImageFile(path.toFile()));
	}

	private void openImageFile(File file) {
		if (!isImageChangeAllowed(getSimulationState())) {
			JOptionPane.showMessageDialog(this,
					"Pause or stop the simulation before changing the target image.",
					"Image Evolution", JOptionPane.INFORMATION_MESSAGE);
			return;
		}
		try {
			BufferedImage image = ImageIO.read(file);
			if (image == null) {
				throw new IOException("The selected file is not a supported image.");
			}
			targetImage = image;
			evolutionPanel.resetForTarget(image);
			recentImages.add(file);
			recentImagesHelper.rebuild(recentImagesMenu);
			resetSimulation(image, requestedTriangles, requestedPopulation,
					requestedFitnessMode);
		} catch (IOException exception) {
			recentImages.remove(file);
			recentImagesHelper.rebuild(recentImagesMenu);
			JOptionPane.showMessageDialog(this,
					"Could not open image:\n" + exception.getMessage(),
					"Open Image Failed", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void updateImageActions(SimulationState state) {
		boolean allowed = isImageChangeAllowed(state);
		if (openImageItem != null) {
			openImageItem.setEnabled(allowed);
		}
		if (recentImagesMenu != null) {
			recentImagesMenu.setEnabled(allowed);
		}
	}

	static boolean isImageChangeAllowed(SimulationState state) {
		return state == SimulationState.READY
				|| state == SimulationState.PAUSED
				|| state == SimulationState.TERMINATED
				|| state == SimulationState.FAILED;
	}
	// -------------------------------------------------------------------------
	// Private helpers
	// -------------------------------------------------------------------------

	/**
	 * Build thumbnail renders for every individual in the current population.
	 * Returns an empty list if the population is not yet available.
	 */
	private List<BufferedImage> buildThumbnails(GeneticAlgorithmSimulation<PolygonChromosome> s) {

		// getPopulationSnapshot() returns a point-in-time copy of the individual
		// list so we don't hold a reference into the live population across a
		// generation boundary. See GeneticAlgorithmSimulation for this accessor.
		List<PolygonChromosome> individuals = s.getPopulationSnapshot();
		List<BufferedImage> thumbs = new ArrayList<>(individuals.size());
		for (PolygonChromosome c : individuals) {
			thumbs.add(c.render(THUMB_SIZE, THUMB_SIZE));
		}
		return thumbs;
	}

	/**
	 * Load the default target image from the classpath resource
	 * {@code /edu/cnu/mdi/sim/ga/demo/image/resources/target.png}. Falls back to a
	 * generated gradient image if the resource is not found, so the demo is always
	 * runnable even without an image on the classpath.
	 */
	private static BufferedImage loadDefaultTarget() {
		String path = Environment.MDI_RESOURCE_PATH + "images/target.png";
		try (InputStream in = ImageEvolutionDemoView.class.getResourceAsStream(path)) {
			if (in != null) {
				return ImageIO.read(in);
			}
		} catch (IOException ignored) {
			// fall through to fallback
		}
		return generateFallbackTarget(200, 200);
	}

	/**
	 * Generate a simple RGB gradient image as a fallback target when no classpath
	 * resource is available. This ensures the demo launches and produces visible
	 * evolution even without a bundled image.
	 */
	private static BufferedImage generateFallbackTarget(int w, int h) {
		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				int r = (x * 255) / w;
				int g = (y * 255) / h;
				int b = 128;
				img.setRGB(x, y, 0xFF000000 | (r << 16) | (g << 8) | b);
			}
		}
		return img;
	}

	/**
	 * Static factory method used in the {@code super(...)} call. Builds a fully
	 * configured {@link GeneticAlgorithmSimulation} for the image approximation
	 * problem.
	 */
	private static GeneticAlgorithmSimulation<PolygonChromosome> createSimulation(BufferedImage target,
			int numTriangles, int populationSize) {
		return createSimulation(target, numTriangles, populationSize,
				ImageFitnessMode.LINE_AWARE);
	}

	private static GeneticAlgorithmSimulation<PolygonChromosome> createSimulation(BufferedImage target,
			int numTriangles, int populationSize, ImageFitnessMode fitnessMode) {

		ImageApproximationProblem problem = new ImageApproximationProblem(
				target, numTriangles, fitnessMode);

		GAConfig cfg = new GAConfig(populationSize, 
				100_000, // maxGenerations — effectively unlimited for demo purposes
				0.70, // crossoverRate
				0.035, // per-triangle mutation rate
				25, // progressEveryGens — update progress every 25 generations
				10, // refreshEveryGens — update population every 10 generations
				1234567L); // randomSeed — set to 0 for true randomness; non-zero for reproducibility

		GAOperators<PolygonChromosome> operators = new GAOperators<>(new TournamentSelection<>(2),
				new UniformBlendCrossover(), new GaussianMutation(cfg.mutationRate(), 0.06, 0.08),
				new ElitistReplacement<>(2));

		GeneticAlgorithmSimulation<PolygonChromosome> sim = new GeneticAlgorithmSimulation<>(problem, cfg, operators);

		// Engine reference is injected after construction in the view constructor.
		// The simulation runs fine without it; it just won't post UI hints until
		// a feedback adapter is attached.
		return sim;
	}

	/**
	 * Cast the simulation held by {@code engine} to the concrete type and attach a
	 * feedback adapter for progress and refresh hints.
	 */
	@SuppressWarnings("unchecked")
	private GeneticAlgorithmSimulation<PolygonChromosome> castSim(SimulationEngine engine) {
		GeneticAlgorithmSimulation<PolygonChromosome> s = (GeneticAlgorithmSimulation<PolygonChromosome>) engine
				.getSimulation();
		s.setFeedback(GAFeedback.forEngine(engine));
		return s;
	}

	/**
	 * Install {@code panel} as the main (left) content area.
	 * <p>
	 * If {@link SimulationView} has already wrapped CENTER in a
	 * {@link JSplitPane} for diagnostics, we replace only the left component
	 * of that split pane — preserving the diagnostics panel on the right.
	 * If there is no split pane (diagnostics disabled), we replace CENTER
	 * directly as before.
	 * </p>
	 */
	private void installCenterPanel(ImageEvolutionPanel panel) {
	    // If a diagnostics split pane exists, replace its left component only.
	    // This preserves the diagnostics panel on the right side.
	    if (diagnosticsSplitPane != null) {
	        diagnosticsSplitPane.setLeftComponent(panel);
	        diagnosticsSplitPane.revalidate();
	        return;
	    }

	    // No split pane — replace CENTER directly (diagnostics disabled case)
	    java.awt.Container cp = getContentPane();
	    if (cp.getLayout() instanceof java.awt.BorderLayout bl) {
	        java.awt.Component current = bl.getLayoutComponent(
	                cp, java.awt.BorderLayout.CENTER);
	        if (current != null) {
	            cp.remove(current);
	        }
	    }
	    cp.add(panel, java.awt.BorderLayout.CENTER);
	    cp.revalidate();
	}
}
